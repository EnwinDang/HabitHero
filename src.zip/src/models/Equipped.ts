export interface Equipped {
  weaponId: string | null;
  helmetId: string | null;
  chestplateId: string | null;
  pantsId: string | null;
  bootsId: string | null;
  accessoryId: string | null;
  petId: string | null;
}
