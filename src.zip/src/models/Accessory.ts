import type { Item } from "./Item";

export interface Accessory extends Item {
  // Bijvoorbeeld speciale buffs / utility effecten
}
