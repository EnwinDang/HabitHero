import type { Item } from "./Item";

export interface Weapon extends Item {
  // Extra velden kunnen later nog toegevoegd worden (attack speed, range, etc.)
}
