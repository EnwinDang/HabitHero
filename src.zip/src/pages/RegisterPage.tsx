import { useState } from "react";
import { AuthService } from "../services/api/AuthService";
import { UserService } from "../services/api/UserService";
import { Link, useNavigate } from "react-router-dom";

export default function Register() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [username, setUsername] = useState("");
  const [err, setErr] = useState("");

  const handleRegister = async () => {
    const res = await AuthService.register(email, pass);

    if (!res.success) {
      setErr(res.error);
      return;
    }

    // Create starter player
    await UserService.createStarterUser(res.uid, username);

    nav("/home");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="bg-gray-800 p-8 rounded-xl shadow-lg w-full max-w-md text-white">

        <h1 className="text-3xl font-bold mb-6 text-center">Create Account</h1>

        {err && <p className="text-red-400 mb-4">{err}</p>}

        <input
          type="text"
          placeholder="Username"
          className="w-full mb-3 p-3 rounded bg-gray-700"
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="email"
          placeholder="Email"
          className="w-full mb-3 p-3 rounded bg-gray-700"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full mb-5 p-3 rounded bg-gray-700"
          onChange={(e) => setPass(e.target.value)}
        />

        <button
          onClick={handleRegister}
          className="w-full bg-green-500 p-3 rounded hover:bg-green-600"
        >
          Register
        </button>

        <p className="mt-4 text-center">
          Already have an account?{" "}
          <Link to="/login" className="text-blue-400 underline">
            Login
          </Link>
        </p>

      </div>
    </div>
  );
}
