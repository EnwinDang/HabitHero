import { useState } from "react";
import { AuthService } from "../services/api/AuthService";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");

  const handleLogin = async () => {
    const res = await AuthService.login(email, pass);
    if (res.success) nav("/home");
    else setError(res.error);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="bg-gray-800 p-8 rounded-xl shadow-lg w-full max-w-md text-white">
        <h1 className="text-3xl font-bold mb-6 text-center">HabitHero</h1>

        {error && <p className="text-red-400 mb-4">{error}</p>}

        <input
          type="email"
          placeholder="Email"
          className="w-full mb-3 p-3 rounded bg-gray-700"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full mb-5 p-3 rounded bg-gray-700"
          onChange={(e) => setPass(e.target.value)}
        />

        <button
          onClick={handleLogin}
          className="w-full bg-blue-500 p-3 rounded hover:bg-blue-600"
        >
          Login
        </button>

        <p className="mt-4 text-center">
          No account?{" "}
          <Link to="/register" className="text-blue-400 underline">
            Register now
          </Link>
        </p>
      </div>
    </div>
  );
}
